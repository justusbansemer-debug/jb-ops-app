import Link from "next/link";

// The top navigation bar shown on every page.
const links = [
  { href: "/", label: "Dashboard" },
  { href: "/customers", label: "Customers" },
  { href: "/jobs", label: "Jobs" },
  { href: "/quotes", label: "Quotes" },
  { href: "/invoices", label: "Invoices" },
];

export default function Nav() {
  return (
    <nav className="bg-slate-900 text-white">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="font-bold text-lg">J.B. Pressure Washing — Ops</div>
        <div className="flex gap-6 text-sm font-medium">
          {links.map((l) => (
            <Link key={l.href} href={l.href} className="hover:text-orange-400">
              {l.label}
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}
